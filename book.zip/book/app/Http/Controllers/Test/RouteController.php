<?php
/**
 * Created by PhpStorm.
 * User: xv
 * Date: 2018/8/14
 * Time: 17:03
 */

namespace App\Http\Controllers\Test;


use App\Http\Controllers\Controller;

class RouteController extends Controller
{
    public function action($id)
    {
        echo $id ;
        return view('welcome');
    }
}